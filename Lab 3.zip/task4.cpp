#include<iostream>
using namespace std;

int main()
{
	int number;
	cout << "enter an integer:";
	cin >> number;
	
	int square = number * number;
	cout << "the square of" << number<<"is:" << square;
}