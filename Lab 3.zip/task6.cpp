#include<iostream>
using namespace std;

int main()
{
	cout << "hello, world!";
	int x = 0;
	cout << "x=" << x;
	return 0;
		
}