#include<iostream>
using namespace std;

int main()
{
	int number;
	cout << "enter an integer:";
	cin >> number;
	cout << "you entered:" << number;
}