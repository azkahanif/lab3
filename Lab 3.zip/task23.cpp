#include <iostream>
#include <iomanip>
using namespace std;

const double PI = 3.14159265358979323846;

int main() {

    double radius, height, volume, surfaceArea;

    cout << "Enter the radius of the cylinder: ";
    cin >> radius;

    cout << "Enter the height of the cylinder: ";
    cin >> height;

    volume = PI * radius * radius * height;

    surfaceArea = 2 * PI * radius * (radius + height);

    cout << fixed << setprecision(2);
    cout << "Volume of the Cylinder: " << volume << " cubic units" << endl;
    cout << "Surface Area of the Cylinder: " << surfaceArea << " square units" << endl;

    return 0;
}