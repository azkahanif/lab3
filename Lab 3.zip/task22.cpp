#include <iostream>
#include <iomanip>
using namespace std;

int main() {

    double weight, height, bmi;

    cout << "Enter your weight in kilograms: ";
    cin >> weight;

    cout << "Enter your height in meters: ";
    cin >> height;

    bmi = weight / (height * height);

    cout << fixed << setprecision(2);
    cout << "Your Body Mass Index (BMI) is: " << bmi << endl;

    return 0;
}