#include <iostream>
using namespace std;

int main() {
    int totalMinutes;


    cout << "Enter the total number of minutes: ";
    cin >> totalMinutes;


    int hours = totalMinutes / 60;
    int minutes = totalMinutes % 60;


    cout << "Total time is: " << hours << " hour(s) and " << minutes << " minute(s)" << endl;

    return 0;
}