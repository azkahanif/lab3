#include<iostream>
using namespace std;

int main()
{
	int x, y;
	cout << "enter two integers (xand y)p:";
	cin >> x >> y;

	int remainder = x % y;
	cout << "the remainder when" << x << "is devided by" << y << "is:" << remainder;
}