#include<iostream>
using namespace std;

int main()
{
	double radius;
   double PI = 3.14;

	cout << "enter the radius of the circle:";
	cin >> radius;

	double area = PI * (radius * radius);

	cout << "the area of the circle is : " << area;
	return 0;
}