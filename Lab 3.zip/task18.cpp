#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int number;

    cout << "Enter a number: ";
    cin >> number;

    cout << "\nNumber\tSquare\tCube\n";
    cout << "--------------------------\n";

    for (int i = 0; i < 5; i++) {
        int currentNumber = number + i;
        int square = currentNumber * currentNumber;
        int cube = currentNumber * currentNumber * currentNumber;

        cout << currentNumber << "\t" << square << "\t" << cube << endl;
    }

    return 0;
}