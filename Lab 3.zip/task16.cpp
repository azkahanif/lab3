#include <iostream>
#include <iomanip>
using namespace std;

int main() {

    double gallons = 12.0;
    double miles = 350.0;

    double MPG = miles / gallons;

    cout << fixed << setprecision(2);
    cout << "Miles per Gallon (MPG): " << MPG << " miles/gallon" << endl;

    return 0;
}