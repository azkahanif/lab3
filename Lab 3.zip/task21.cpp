#include <iostream>
using namespace std;

int main() {

    const int basicCoursePrice = 500;
    const int advancedCoursePrice = 1000;
    const int professionalCoursePrice = 2000;

    int basicCourses, advancedCourses, professionalCourses;

    cout << "Enter the number of Basic courses you want to enroll in: ";
    cin >> basicCourses;

    cout << "Enter the number of Advanced courses you want to enroll in: ";
    cin >> advancedCourses;

    cout << "Enter the number of Professional courses you want to enroll in: ";
    cin >> professionalCourses;

    int totalCost = (basicCourses * basicCoursePrice) +
        (advancedCourses * advancedCoursePrice) +
        (professionalCourses * professionalCoursePrice);

    double discount = 0.15; // 15% discount
    double discountAmount = totalCost * discount;

    double finalAmount = totalCost - discountAmount;

    cout << "\nTotal Cost: Rs " << totalCost << endl;
    cout << "Discount Amount: Rs " << discountAmount << endl;
    cout << "Final Amount Due: Rs " << finalAmount << endl;

    return 0;
}