#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    string studentname;
    int rollNumber;
    string subject1, subject2, subject3;
    int marks1, marks2, marks3;
    int totalMarks;
    float percentage;


    cout << "Enter Student Name: ";
    cin >> studentname;

    cout << "Enter Roll Number: ";
    cin >> rollNumber;


    cout << "Enter name of Subject 1: ";
    cin >> subject1;
    cout << "Enter marks in " << subject1 << ": ";
    cin >> marks1;

    cout << "Enter name of Subject 2: ";
    cin >> subject2;
    cout << "Enter marks in " << subject2 << ": ";
    cin >> marks2;

    cout << "Enter name of Subject 3: ";
    cin >> subject3;
    cout << "Enter marks in " << subject3 << ": ";
    cin >> marks3;

    totalMarks = marks1 + marks2 + marks3;
    percentage = (totalMarks / 3.0);

    cout << "\n----- Result Sheet -----\n";
    cout << "Student Name : " << studentname << endl;
    cout << "Roll Number  : " << rollNumber << endl;

    cout << "\nSubjects and Marks:\n";
    cout << left << setw(15) << "Subject" << setw(10) << "Marks" << endl;
    cout << left << setw(15) << subject1 << setw(10) << marks1 << endl;
    cout << left << setw(15) << subject2 << setw(10) << marks2 << endl;
    cout << left << setw(15) << subject3 << setw(10) << marks3 << endl;

    cout << "\nTotal Marks  : " << totalMarks << "/300" << endl;
    cout << "Percentage   : " << fixed << setprecision(2) << percentage << "%" << endl;

    return 0;
}