#include<iostream>
using namespace std;

int main()
{
	int score1, score2, score3, score4, score5;
	cout << "enter the first test score:";
	cin >> score1;

	cout << "enter the second score:";
	cin >> score2;

	cout << "enter the third score:";
	cin >> score3;

	cout << "enter the fourth score:";
	cin >> score4;

	cout << "enter the fifth score:";
	cin >> score5;

	double average = (score1 | +score2 + score3 + score4 + score5);

	cout << "the average test score is :" << average;
	return 0;
}

