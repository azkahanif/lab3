#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    float priceWheat, priceRice, priceSugar;
    int qtyWheat, qtyRice, qtySugar;
    float totalWheat, totalRice, totalSugar, grandTotal;

    cout << "Enter price of Wheat per unit: ";
    cin >> priceWheat;
    cout << "Enter quantity of Wheat: ";
    cin >> qtyWheat;

    cout << "Enter price of Rice per unit: ";
    cin >> priceRice;
    cout << "Enter quantity of Rice: ";
    cin >> qtyRice;


    cout << "Enter price of Sugar per unit: ";
    cin >> priceSugar;
    cout << "Enter quantity of Sugar: ";
    cin >> qtySugar;


    totalWheat = priceWheat * qtyWheat;
    totalRice = priceRice * qtyRice;
    totalSugar = priceSugar * qtySugar;


    grandTotal = totalWheat + totalRice + totalSugar;


    cout << "\n----- Total Value of Items -----\n";
    cout << "Wheat : Quantity = " << qtyWheat << ", Price = Rs " << priceWheat << ", Total Value = Rs " << totalWheat << endl;
    cout << "Rice  : Quantity = " << qtyRice << ", Price = Rs " << priceRice << ", Total Value = Rs " << totalRice << endl;
    cout << "Sugar : Quantity = " << qtySugar << ", Price = Rs " << priceSugar << ", Total Value = Rs " << totalSugar << endl;

    cout << "\nGrand Total Value: Rs " << grandTotal << endl;

    return 0;
}