#include <iostream>
using namespace std;

int main() {
    float width, length;


    cout << "Enter the width of the rectangle: ";
    cin >> width;
    cout << "Enter the length of the rectangle: ";
    cin >> length;


    float area = width * length;
    float perimeter = 2 * (width + length);


    cout << "The area of the rectangle is: " << area << endl;
    cout << "The perimeter of the rectangle is: " << perimeter << endl;

    return 0;
}