#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    const int priceA = 15;
    const int priceB = 12;
    const int priceC = 9;

    int ticketsA, ticketsB, ticketsC;
    int incomeA, incomeB, incomeC, totalIncome;


    cout << "Enter the number of Class A tickets sold: ";
    cin >> ticketsA;

    cout << "Enter the number of Class B tickets sold: ";
    cin >> ticketsB;

    cout << "Enter the number of Class C tickets sold: ";
    cin >> ticketsC;


    incomeA = ticketsA * priceA;
    incomeB = ticketsB * priceB;
    incomeC = ticketsC * priceC;


    totalIncome = incomeA + incomeB + incomeC;


    cout << "\n----- Income Generated from Tickets -----\n";
    cout << "Class A tickets sold : " << ticketsA << " | Income: Rs " << incomeA << endl;
    cout << "Class B tickets sold : " << ticketsB << " | Income: Rs " << incomeB << endl;
    cout << "Class C tickets sold : " << ticketsC << " | Income: Rs " << incomeC << endl;
    cout << "\nTotal Income         : Rs " << totalIncome << endl;

    return 0;
}