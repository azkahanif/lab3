#include <iostream>
using namespace std;

int main() {

    int speed = 20;
    int time = 10;
    int distance;

    distance = speed * time;

    cout << "Distance: " << distance << endl;

    return 0;
}