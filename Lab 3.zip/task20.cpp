#include <iostream>
using namespace std;

int main() {

    const int gourmetPrice = 50;
    const int standardPrice = 30;
    const int fastPrice = 20;

    int gourmetMeals, standardMeals, fastMeals;

    cout << "Enter the number of Gourmet meals sold: ";
    cin >> gourmetMeals;

    cout << "Enter the number of Standard meals sold: ";
    cin >> standardMeals;

    cout << "Enter the number of Fast meals sold: ";
    cin >> fastMeals;

    int totalRevenue = (gourmetMeals * gourmetPrice) +
        (standardMeals * standardPrice) +
        (fastMeals * fastPrice);

    cout << "\nTotal Revenue Generated: Rs " << totalRevenue << endl;

    return 0;
}