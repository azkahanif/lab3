using namespace std;
#include<iostream>

int main()
{
	cout << "\t\tHello, Class! \n\tWelcome to the ITC-Lab Week-03";
	
	return 0;
}