#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int Fuel, Rent, Bills, Total;

    cout << "Enter the amount for Fuel: ";
    cin >> Fuel;

    cout << "Enter the amount for Rent: ";
    cin >> Rent;

    cout << "Enter the amount for Bills: ";
    cin >> Bills;

    Total = Fuel + Rent + Bills;

    cout << "\n----- Expenses -----\n";
    cout << left << setw(10) << "Category" << setw(10) << "Amount" << endl;
    cout << left << setw(10) << "Fuel" << setw(10) << Fuel << endl;
    cout << left << setw(10) << "Rent" << setw(10) << Rent << endl;
    cout << left << setw(10) << "Bills" << setw(10) << Bills << endl;
    cout << "---------------------" << endl;
    cout << left << setw(10) << "Total" << setw(10) << Total << endl;

    return 0;
}